<?php

/**
 * Smarty block function for defining content-regions which can be dynamically-altered
 *
 * @see CRM_Core_Regions
 *
 * @param array $params   must define 'name'
 * @param string $content    Default content
 * @param object $smarty  the Smarty object
 *
 * @return string
 */
function smarty_block_crmRegion($params, $content, &$smarty, &$repeat)
{
  if ($repeat) return;
  require_once 'CRM/Core/Region.php';
  $region = CRM_Core_Region::instance($params['name'], FALSE);
  if ($region) {
    $result = $region->render($content);
    return $result;
  } else {
    return $content;
  }
}
