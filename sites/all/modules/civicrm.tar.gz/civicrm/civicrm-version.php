<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.2.0',
                'cms'      => 'Drupal',
                'revision' => '42055' );
}

